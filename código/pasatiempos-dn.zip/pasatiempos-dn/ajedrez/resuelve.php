<!DOCTYPE html>

<html>
  <head>
    <meta charset="UTF-8">
    <title>Ajedrez - David Álvarez</title>
  </head>

  <body background="../img/background.jpg">
	<h1 align="center" style="margin-left: 40px; margin-right: 40px;">Ajedrez - David Álvarez</h1>
	<a href="../index.html">
	    <img src="../img/home.png" height="30px" style="position: absolute; top: 22px; left: 15px; height: 30px; width: 30px;" />
	</a>
    
    
    <br><br><br>
    <p align="center">Página en construcción.</p>
  </body>
</html>
