function info_grafo() {
    alert("Ponga todas las cifras del 1 al 9 en los círculos, para que la suma de las que rodean cada región sea igual al total que figura en ella.");
}


function info_sudoku() {
    alert("Complete los tableros (subdivididos en nueve cuadrados) de 81 casillas dispuestas en nueve filas y columnas, rellenando las celdas vacías con números del 1 al 9, de modo que no se repita ninguna cifra en cada fila, columna o cuadrado.");
}


function info_deduccion() {
    alert("Deduzca cuál es la palabra que tiene tantas letras en común con las que facilitamos como se indica en la primera columna. La segunda columna indica cuántas de esas letras están en el mismo sitio que en la palabra a deducir.");
}


function info_codigo() {
    alert("Descarga todo el código que hace posible esta Web.");
}
